def es_bisiesto(año):
    """ Recibe un año y retorna True si dicho año es bisiesto y False en caso
    contrario """
    if((año % 4 == 0) or (año % 400 == 0)):
        return True
    return False

dia = int(input("Dame día de la fecha: "))
mes = int(input("Dame mes de la fecha: "))
año = int(input("Dame año de la fecha: "))

while(dia <= 0 or dia > 31):
    dia = int(input("Dame día de la fecha: "))
while(mes < 1 or mes > 12):
    mes = int(input("Dame mes de la fecha: "))
while(año <= 0):
    año = int(input("Dame año de la fecha: "))

dia_sal = 0
mes_sal = 0
año_sal = 0

if(dia == 30 and (mes == 4 or mes == 6 or mes == 9 or mes == 11)): ## meses con 30 dias
    dia_sal = 1
    mes_sal = mes + 1
    año_sal = año
else: ## meses con 31 dias
    if(dia == 28 and mes == 2):
        if(es_bisiesto(año)): ## año bisiesto
            dia_sal = dia + 1
            mes_sal = mes
            año_sal = año
        else: ## año no bisiesto
            dia_sal = 1
            mes_sal = 3
            año_sal = año
    elif(dia == 31):
        if(mes == 12):
            dia_sal = 1
            mes_sal = 1
            año_sal = año + 1
        else:
            dia_sal = 1
            mes_sal = mes + 1
            año_sal = año
    else:
        dia_sal = dia + 1
        mes_sal = mes
        año_sal = año

print("Fecha del día siguiente:",dia_sal,"/",mes_sal,"/",año_sal)