
def ejerc3(nombre1,nombre2,palabra):
    """ Recibe el nombre de un fichero (nombre1), una palabra (palabra) y crea
    un fichero de salida con un nombre pasado por parámetro (nombre2) con las
    palabras sin repetir, ordenadas, y una por línea, que estando en el fichero
    (nombre1), contengan el mismo número de todas y cada una de las 5 vocales
    que tiene (palabra) """
    f1 = open(nombre1,'r')
    f2 = open(nombre2,'w')
    lista_sin_repetir = []
    for x in f1:
        linea = x.strip('\n').split(',')
        for y in linea:
            if(y not in lista_sin_repetir):
                lista_sin_repetir.append(y)

    contador_vocales_palabra = cuenta_vocales(palabra)

    lista_palabras_cumplen_requisito = filtra_palabras(sorted(lista_sin_repetir),contador_vocales_palabra)

    for x in lista_palabras_cumplen_requisito:
        f2.writelines(str(x) + '\n')

    f1.close()
    f2.close()


def cuenta_vocales(palabra):
    """ Recibe una palabra y retorna una lista de listas con las vocales que
    tiene la palabra pasada por parámetro y el número de apariciones de cada
    una de estas """
    vocales = ["a","e","i","o","u"]
    contador_vocales = [0,0,0,0,0]
    for x in palabra:
        if(x == "a"):
            contador_vocales[0] = contador_vocales[0] + 1
        elif(x == "e"):
            contador_vocales[1] = contador_vocales[1] + 1
        elif(x == "i"):
            contador_vocales[2] = contador_vocales[2] + 1
        elif(x == "o"):
            contador_vocales[3] = contador_vocales[3] + 1
        elif(x == "u"):
            contador_vocales[4] = contador_vocales[4] + 1

    return borrar_innecesarios(vocales,contador_vocales)



def borrar_innecesarios(vocales,contador_vocales):
    """ Recibe dos listas, una de vocales y un contador para cada vocal
    y borra los elementos que no tenga el contador superior a 0. Retorna las
    listas resultantes """
    for x in range(len(contador_vocales)-1,-1,-1):
        if(contador_vocales[x] == 0):
            vocales.pop(x)
            contador_vocales.pop(x)

    return vocales,contador_vocales


def filtra_palabras(lista_palabras,lista_contadores):
    """ Recibe una lista de palabras ordenadas y otra lista de listas con cada
    vocal y un numero de apariciones correspondiente a cada vocal. Busca en la
    primera lista recibida las palabras que tengan el mismo número y mismas
    vocales que en los contadores pasados por parámetro y elimina de la primera
    lista las palabras que no cumplen con el requisito. Retorna la lista
    resultante """
    for x in lista_palabras[:]:
        aux = cuenta_vocales(x)
        if(aux != lista_contadores):
            lista_palabras.pop(lista_palabras.index(x))

    return lista_palabras


ejerc3("palabras.txt","listado.txt","cotorra")





