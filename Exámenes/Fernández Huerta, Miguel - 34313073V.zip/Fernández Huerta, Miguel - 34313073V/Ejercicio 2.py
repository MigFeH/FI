
def función(lista):
    """ Recibe una lista de cadenas de caracteres y retorna otra lista con las
    cadenas que tienen al menos dos vocales tanto mayúsculas como minúsculas,
    acentuadas o no e incluyendo la ü. También elimina de la lista original
    todas estas cadenas que cumplen la condición anterior """
    lsal = []
    vocales_minusculas = ["a","e","i","o","u","á","é","í","ó","ú","ü"]
    vocales_mayusculas = ["A","E","I","O","U","Á","É","Í","Ó","Ú","Ü"]

    for palabra in lista:
        cont = 0
        for letra in palabra[:]:
            if ((letra in vocales_minusculas) or (letra in vocales_mayusculas)):
                cont = cont + 1
        if(cont >= 2):
                lsal.append(palabra)


    for i in range(len(lista)-1,-1,-1):
        if(lista[i] in lsal):
            lista.pop(i)

    return lsal


lista_parametro = "estÓ es uná prüeba de variAs palabras con diferentes vocales".split()
print("Lista parámetro antes de llamada:", lista_parametro)
lista_cadenas_con_dos_vocales = función(lista_parametro)
print("Lista parámetro después de llamada:", lista_parametro)
print("Lista retornada de la llamada:", lista_cadenas_con_dos_vocales)