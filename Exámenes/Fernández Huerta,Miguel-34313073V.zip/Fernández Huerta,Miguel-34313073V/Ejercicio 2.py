
# Ejercicio 2

def barajar(lista):
    """Recibe lista de enteros y corta la lista en dos trozos, alternando los trozos"""
    if len(lista)%2==0:
        listaf=[]
        lista1=lista[0:len(lista)-1:2]
        lista2=lista[1:len(lista)-1:2]
        for x in range(0,len(lista2),2):
            listaf=lista1
            listaf.insert(x,lista2[x])
        lista=listaf
    else:
        listaf=[]
        lista1=lista[0:len(lista)//2:2]
        lista2=lista[len(lista)//2:len(lista):2]
        for x in range(0,len(lista2),2):
            listaf=lista1
            listaf.insert(x+1,lista2[x])
        lista=listaf



lista=[10,20,30,40,50,60]
listaImpar=[10,20,30,40,50,60,70]
barajar(lista)
barajar(listaImpar)
print(lista)
print(listaImpar)


