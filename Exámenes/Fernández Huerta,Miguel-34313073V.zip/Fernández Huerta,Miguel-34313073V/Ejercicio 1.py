from random import*

# Ejercicio 1

n=-1
while n<0:
    n=int(input("Dame número de margaritas: "))
m=-1
while m<0:
    m=int(input("Dame número de pétalos de las margaritas: "))
s0=0
s1=0
for i in range(n):
    for j in range(m):
        k=randint(0,1)
        if k==0:
            s0=s0+1
        else:
            s1=s1+1
if s1>s0:
    print("Tu pareja te quiere")
elif s1==s0:
    print("Tu pareja te quiere")
else:
    print("Tu pareja no te quiere")












