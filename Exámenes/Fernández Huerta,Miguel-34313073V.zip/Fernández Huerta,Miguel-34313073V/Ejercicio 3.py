
# Ejercicio 3

def ej3B(nombre1,nombre2,secuencia):
    """Recibe un fichero de entrada nombre1 y una cadena secuencia formada por una seria de cifras
    en el rango [0...9] y crea el fichero de salida nombre2"""
    f1=open(nombre1,'r')
    f2=open(nombre2,'w')
    cad=[]
    listaNoRep=[]
    y=secuencia
    for linea in f1:
        x=linea.strip("\n").split(";")
        for i in x:
            if i not in listaNoRep:
                listaNoRep.append(i)
        listaNoRep=sorted(listaNoRep)
        cadf='\n'.join(listaNoRep)
        if y in cadf:
            f2.write(cadf)
    f1.close()
    f2.close()

nombre1="ejemplo"+".txt"
nombre2="resu"+".txt"
ej3B(nombre1,nombre2,"561")

