#### ESTE ES EL MÓDULO NOV30pr.py
#### CLASE DE PRÁCTICAS SOBRE CADENAS/FICHEROS DE
#### Martes [30/Nov,7 DIC],
#### Miércoles 1/DIC,
#### Jueves 2/DIC,
#### Viernes 3/DIC


#### Guión LISTAS II (trabajad sobre él)



#### RECORDATORIO CLASE TEORÍA del 25/NOV

#### INTENTAR HACER LAS FUNCIONES QUE SIMULEN
#### A LAS CORRESPONDIENTES DEL PYTHON:

def nuestra_strip(cad,x):
    """que devuelva otra cadena que sea como cad, pero
    quitando los caractéres x por ambos extremos"""
#   programarlo

def nuestra_rstrip(cad,x):
    """que devuelva otra cadena que sea como cad, pero
    quitando los caractéres x por el extremo derecha"""
#    programarlo

def nuestra_lstrip(cad,x):
    """que devuelva otra cadena que sea como cad, pero
    quitando los caractéres x por el extremo izquierdo"""
#   programarlo

#n2="*****HOLA *Y* ADIOS**"
#print(nuestra_strip(n2,"*")
#print(nuestra_rstrip(n2,"*")
#print(nuestra_lstrip(n2,"*")



#### VAMOS A TRABAJAR SOBRE UNOS FICHEROS zanimales1.txt,
#### zanimales2.txt y zanimales3.txt creados con el
#### Bloc de Notas o con NOV30.CrearFichero



#####EJERCICIO 1

def contarLetras(nombre,letra):
    """Se pasa nombre de un fichero y una letra  y se
    ha de devolver el número de letras total de fichero
    (excluidos blancos y saltos de línea)
    y el número de veces que aparece letra"""
    contTotal=0
    contLetra=0
    f=open(nombre,"r")
    #lista=f.readlines()
    for linea in f:
        linea=linea[0:len(linea)-1:1]
        # también valdría linea.strip("\n") o linea.strip()
        #print(linea)
        for x in linea:
            if x!=" ":
                contTotal=contTotal+1
            if x==letra:
                contLetra=contLetra+1
    f.close()
    return contTotal,contLetra

##nom=input("NOMBRE DEL FICHERO SIN EXTENSIÓN?=")
##nom=nom+".txt"
##le=input("LETRA A CONTAR")
##res=contarLetras(nom,le)
##print(res)
##print(round(100*res[1]/res[0],2))




#### EJERCICIO 2

#### Escribir una función que reciba un fichero
#### y escriba QUÉ VOCAL MINÚSCULA APARECE MÁS
#### VECES EN EL FICHERO Y CUÁNTAS VECES APARECE?
#### En CASO DE EMPATE, HAY QUE PONERLAS TODAS


def vocalesModa (nombre):
    """hace lo del enunciado"""
    vocales=["a","e","i","o","u"]
    contVocales=[]
    for x in vocales:
        contVocales.append(contarLetras(nombre,x)[1])
    print(contVocales)
    ma=max(contVocales)
    print("VOCALES MAYORITARIAS")
    for i in range(len(vocales)):
        if contVocales[i]==ma:
           print(vocales[i],"VECES=",ma)

##nom=input("NOMBRE DEL FICHERO SIN EXTENSIÓN?=")
##nom=nom+".TXt"
##vocalesModa(nom)



#### EJERCICIO 3

def contarPalabras(nombre,palabra):
    """pasan nombre de un fichero y una palabra  y se ha de
    devolver número de veces que está palabra en el fichero"""
    cont=0
    f=open(nombre,"r")
    for linea in f:
        lista=linea[:len(linea)-1:].split()
        #lista=linea.strip().split()
        #print(lista)
        for x in lista:
            if x==palabra:
                cont=cont+1
    f.close()
    return cont
##nom=input("NOMBRE DEL FICHERO SIN EXTENSIÓN?=")
##nom=nom+".TXt"
##pa=input("animal?")
##print(contarPalabras(nom,pa))



#### EJERCICIO 4

#### ¿QUÉ PALABRA (animal) APARECE MÁS VECES EN UN FICHERO
#### Y CUÁNTAS VECES APARECE?
#### EN CASO DE EMPATE, HAY QUE PONERLOS TODOS LOS ANIMALES
#### ORDENADOS ALFABÉTICAMENTE


def ordenar(l):
    """recibe una lista l y la retorna ordenada"""
    ##return sorted(l)
    ##lo vamos hacer sin utilizar ni el sorted,
    ##ni las funciones min y max de Python
    for i in range(len(l)):
        mi=l[i]
        for j in range (i,len(l)):
            if l[j]<mi:
                mi=l[j]
                pos=j
        x=l[i]
        l[i]=l[pos]
        l[pos]=x
    return(l)

##lista=[4,6,8,3,4,1,1,-9,0]
##print(ordenar(lista))


def etapa1(nombre):
    """ Hacer lista no repetida de animales que aparezcan
    en el fichero, después ordenarla y devolverla"""
    f=open(nombre,"r")
    lNoRep=[]
    for linea in f:
        for x in linea.strip("\n").split(" "):
            if not x in lNoRep:
                lNoRep.append(x)
    #print(lNoRep)
    lNoRep=ordenar(lNoRep)
    #print(lNoRep)
    return(lNoRep)


def etapa2(nombre,l):
    """ver cuántas veces aparece cada animal,
    calcular el máximo de apariciones
    y escribir moda múltiple"""
    lCont=[]
    for x in l:
        lCont.append(contarPalabras(nombre,x))
        #print(lCont)
    #print (lCont)
    ma=max(lCont)
    #print(ma)
    print("ANIMALES PREFERIDOS=")
    for i in range (len(lCont)):
        if lCont[i]==ma:
            print("ANIMAL=",l[i],"VOTOS=",ma)


def animalesModa(nombre):
    """hace lo pedido)"""
    lista=etapa1(nombre)
    #print(lista)
    etapa2(nombre,lista)

nom=input("NOMBRE DEL FICHERO SIN EXTENSIÓN?=")
nom=nom+".TXt"
animalesModa(nom)
