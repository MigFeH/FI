# Operaciones avanzadas con listas, eliminación de negativos
# Escrito por José A. Corrales 22-nov-2021

def elimina_negativos(lista):
    # elimina los negativos de la lista pasada como parámetro
    lista[:]=[x for x in lista if x>=0]

mi_lista=[1,-6,23,-16,-7,-7,-7,4,2,-5]
print(mi_lista)
elimina_negativos(mi_lista)
print(mi_lista)