# Operaciones avanzadas con listas, eliminación de negativos
# Escrito por José A. Corrales 22-nov-2021

def elimina_negativos(lista):
    # elimina los negativos de la lista pasada como parámetro
    # vamos del final hacia el principio para evitar problemas
    # con los huecos de los que se van eliminando
    for i in range(len(lista)-1,-1,-1):
        if lista[i]<0:
            lista.pop(i)

mi_lista=[1,-6,23,-16,-7,-7,-7,4,2,-5]
print(mi_lista)
elimina_negativos(mi_lista)
print(mi_lista)